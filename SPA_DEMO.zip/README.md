
    框架：Laravel + Sanctum 
	前端：Vue + Vue router + Tailwind
	資料庫：MySQL

	Other：
	Google map Api
	Python Beautifulsoup
    canvas

以補習班電子化管理需求設計


RWD練習

![RWD01](https://user-images.githubusercontent.com/71909860/153897173-4e03033b-cb2f-49bf-830c-923cd8dd9cda.gif)
![RWD03](https://user-images.githubusercontent.com/71909860/153897899-f791c22f-ca76-4fb4-8ac9-1a60939ddc4a.gif)

JS互動

![JS01](https://user-images.githubusercontent.com/71909860/153900602-d6cace6c-7a90-4ff5-b036-2cd9a4e016a7.gif)
![JS02](https://user-images.githubusercontent.com/71909860/153900609-27566e79-6731-41d9-9b0e-236a9e0ba90e.gif)
![JS03](https://user-images.githubusercontent.com/71909860/153900607-df9ecd9d-cdf5-4478-ad8c-efb05bec1643.gif)

other

![Google01](https://user-images.githubusercontent.com/71909860/153901271-21919f14-a1c0-4bc6-919a-305227e51ea3.gif)
![Sanctum](https://user-images.githubusercontent.com/71909860/153901275-6529cd43-b68b-4b63-9404-9bb6d37379a3.gif)

canvas

![ezgif-4-5f5eb21b4a](https://user-images.githubusercontent.com/71909860/156612645-2a6d909a-df32-420d-9744-5b38ebe477e8.gif)
