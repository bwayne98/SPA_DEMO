

<?php $__env->startSection("app"); ?>

    <router-view name="nav"></router-view>
    <router-view></router-view>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BM\Desktop\Laravel_project\SPA_DEMO\resources\views/welcome.blade.php ENDPATH**/ ?>