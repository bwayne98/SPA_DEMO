@extends("layout")

@section("app")

    <router-view name="nav"></router-view>
    <router-view></router-view>

@endsection